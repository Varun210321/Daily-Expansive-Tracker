package com.example.tictactoe.repository;

import org.springframework.stereotype.Repository;
import java.util.HashMap;
import java.util.Map;

@Repository
public class GameRepository {
    private Map<String, Integer> playerWins;

    public GameRepository() {
        playerWins = new HashMap<>();
    }

    // Method to increment the win count for a player
    public void incrementPlayerWins(String playerName) {
        playerWins.put(playerName, playerWins.getOrDefault(playerName, 0) + 1);
    }

    // Method to get the win count for a player
    public int getPlayerWins(String playerName) {
        return playerWins.getOrDefault(playerName, 0);
    }

    // Method to reset the win count for all players
    public void resetPlayerWins() {
        playerWins.clear();
    }
}
