package com.example.tictactoe.service;

import org.springframework.stereotype.Service;

@Service
public class GameService {
    private char[][] board;
    private char currentPlayer;
    private static final int SIZE = 3;

    public GameService() {
        initializeBoard();
        currentPlayer = 'X'; // 'X' starts the game
    }

    // Initialize the board with empty cells
    private void initializeBoard() {
        board = new char[SIZE][SIZE];
        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                board[row][col] = ' ';
            }
        }
    }

    // Get the current player's symbol
    public char getCurrentPlayer() {
        return currentPlayer;
    }

    // Make a move at the specified position
    public void makeMove(int row, int col) {
        if (board[row][col] == ' ') {
            board[row][col] = currentPlayer;
            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X'; // Switch player
        }
    }

    // Check if the board is full
    public boolean isBoardFull() {
        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                if (board[row][col] == ' ') {
                    return false;
                }
            }
        }
        return true;
    }

    // Check if there is a winner
    public char checkWinner() {
        // Check rows
        for (int i = 0; i < SIZE; i++) {
            if (board[i][0] == board[i][1] && board[i][1] == board[i][2] && board[i][0] != ' ') {
                return board[i][0];
            }
        }
        // Check columns
        for (int i = 0; i < SIZE; i++) {
            if (board[0][i] == board[1][i] && board[1][i] == board[2][i] && board[0][i] != ' ') {
                return board[0][i];
            }
        }
        // Check diagonals
        if (board[0][0] == board[1][1] && board[1][1] == board[2][2] && board[0][0] != ' ') {
            return board[0][0];
        }
        if (board[0][2] == board[1][1] && board[1][1] == board[2][0] && board[0][2] != ' ') {
            return board[0][2];
        }
        // No winner
        return ' ';
    }
}

